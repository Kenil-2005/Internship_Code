import { Component } from '@angular/core';
import { Employee } from '../../Employee';
import { CommonModule } from "@angular/common";
import { EmployeeCardComponent } from "../employee-card/employee-card.component";

@Component({
    selector: 'app-employee-dashboard',
    standalone: true,
    imports: [CommonModule, EmployeeCardComponent],
    templateUrl: './employee-dashboard.component.html',
    styleUrl: './employee-dashboard.component.css'
})
export class EmployeeDashboardComponent {
    EmployeeData: Employee[] = [
        { id: 101, name: 'kenil pansara', department: ' IT', designation: 'Developer', salary: 50000, image: './assets/profile-pic.jpg', promote: false, rate: 5 },
        { id: 102, name: 'divya patel', department: 'HR', designation: 'QA', salary: 80000, image: './assets/profile-pic.jpg', promote: false, rate: 5 },
        { id: 103, name: 'mihir modh', department: 'Finance', designation: 'project manager', salary: 40000, image: './assets/profile-pic.jpg', promote: true, rate: 5 },
        { id: 104, name: 'shruti thakkar', department: 'Marketing', designation: 'BDE', salary: 500000, image: './assets/profile-pic.jpg', promote: false, rate: 5 },
        { id: 105, name: 'krish dave', department: 'IT', designation: 'BDA', salary: 50000, image: './assets/profile-pic.jpg', promote: false, rate: 5 },
    ];

    EmployeePromote(employee: Employee) {
        this.EmployeeData = this.EmployeeData.map(emp =>
            emp.id === employee.id ? { ...emp, promote: !emp.promote } : emp)
    }

    message?: string;

    messagePromote(msg: string) {
        this.message = msg;
        this.hideMsg();
    }
    hideMsg() {
        setTimeout(() => {
            this.message = undefined;
        }, 4000);
    }

    EmployeeRate(msg: string) {
        this.message = msg;
        this.hideMsg();
    }


}
