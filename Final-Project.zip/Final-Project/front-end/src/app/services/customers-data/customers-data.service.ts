import { HttpClient, HttpHeaders } from '@angular/common/http';
import { inject, Injectable } from '@angular/core';
import { map, Observable, tap } from 'rxjs';
import { MCustomer } from '../../Model/MCustomer';
import { RepositoryStateService } from '../repository-state/repository-state.service';

@Injectable({
    providedIn: 'root'
})
export class CustomersDataService {
    private http = inject(HttpClient);
    private stateService = inject(RepositoryStateService);
    private apiUrl = 'http://localhost:5000/api/customer';

    getCustomers(IChoice: string): Observable<MCustomer[]> {
        const headers = new HttpHeaders({
            choice: IChoice
        })

        return this.http.get<any>(this.apiUrl, { headers }).pipe(
            tap(response => console.log('GET API Raw Response:', response)),
            map(response => response.data || [])
        );
    }

    CreateCustomer(IChoice: string, body: MCustomer): Observable<MCustomer> {
        const headers = new HttpHeaders({
            choice: this.stateService.choice()
        });

        return this.http.post<any>(this.apiUrl, body, { headers }).pipe(
            tap(response => console.log('POST API Raw Response:', response)),
        );
    }

    UpdateCustomer(IChoice: string, inputId: number, body: MCustomer): Observable<MCustomer> {
        const headers = new HttpHeaders({
            choice: this.stateService.choice()
        });

        return this.http.put<any>(`${this.apiUrl}/${inputId}`, body, { headers }).pipe(
            tap(response => console.log('PUT API Raw Response:', response)),
        );
    }

    DeleteCustomer(IChoice: string, inputId: number): Observable<MCustomer> {
        const headers = new HttpHeaders({
            choice: this.stateService.choice()
        });

        return this.http.delete<any>(`${this.apiUrl}/${inputId}`, { headers }).pipe(
            tap(response => console.log('DELETE API Raw Response:', response)),
        );
    }
}
