import { Component, inject } from '@angular/core';
import {
    MAT_DIALOG_DATA,
    MatDialogTitle,
    MatDialogContent,
} from '@angular/material/dialog';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-employee-dialog',
    standalone: true,
    imports: [MatDialogTitle, MatDialogContent, CommonModule],
    templateUrl: './employee-dialog.component.html',
    styleUrl: './employee-dialog.component.css'
})
export class EmployeeDialogComponent {
    data = inject(MAT_DIALOG_DATA);
}
