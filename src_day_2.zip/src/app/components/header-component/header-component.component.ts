import { Component } from '@angular/core';

@Component({
  selector: 'app-header-component',
  standalone: true,
  imports: [],
  templateUrl: './header-component.component.html',
  styleUrl: './header-component.component.css'
})
export class HeaderComponentComponent {
  HeaderData = {
    Name: 'ABC Technologies', Logo: 'Dev.', Title: 'Employee Managment Portal'
  };
}
