import { Component, inject, Input, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { EmployeeServiceService } from '../../service/employee-service.service';
import { employee } from '../../Employee';
import { CommonModule } from '@angular/common';

@Component({
    selector: 'app-employee-details',
    standalone: true,
    imports: [CommonModule, RouterLink],
    templateUrl: './employee-details.component.html',
    styleUrl: './employee-details.component.css'
})
export class EmployeeDetailsComponent implements OnInit {
    private employeeService = inject(EmployeeServiceService);
    private router = inject(Router);

    @Input() id?: any;

    selectedEmployee: employee | undefined;

    ngOnInit(): void {
        const numericId = Number(this.id);

        this.selectedEmployee = this.employeeService.getEmployeeData()
            .find(emp => emp.id === numericId);

        if (!this.selectedEmployee) {
            console.warn(`Employee with ID ${this.id} not found.`);
            this.router.navigate(['/employee']);
        }
    }
}
