import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { EmployeeServiceService } from '../../service/employee/employee-data.service';
import { Employee } from '../../Employee';

@Component({
    selector: 'app-employee-list',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './employee-list.component.html',
    styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent implements OnInit {
    private router = inject(Router);
    private employeeService = inject(EmployeeServiceService);

    EmployeeData: Employee[] = [];

    ngOnInit(): void {
        this.employeeService.getEmployee().subscribe({
            next: (data: Employee[]) => {
                this.EmployeeData = data;
                console.log('UI Bound Data:', this.EmployeeData);
            },
            error: (err) => {
                console.error('Failed to stream profiles from API backend:', err);
            }
        });
    }

    onCardClick(id: number | string): void {
        this.router.navigate(['/employee-details', id]);
    }
}