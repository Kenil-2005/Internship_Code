import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { EmployeeComponentComponent } from "./components/employee-component/employee-component.component";
import { HeaderComponentComponent } from "./components/header-component/header-component.component";
import { FooterComponentComponent } from "./components/footer-component/footer-component.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [FormsModule, EmployeeComponentComponent, HeaderComponentComponent, FooterComponentComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'employee-managment-potal';
}
