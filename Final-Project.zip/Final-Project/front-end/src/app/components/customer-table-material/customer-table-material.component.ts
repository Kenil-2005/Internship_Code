import { Component, inject } from '@angular/core';
import { ViewChild } from '@angular/core';
import { MatPaginator, MatPaginatorModule } from '@angular/material/paginator';
import { MatSort, MatSortModule } from '@angular/material/sort';
import { MatTableDataSource, MatTableModule } from '@angular/material/table';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MCustomer } from '../../Model/MCustomer';
import { CustomersDataService } from '../../services/customers-data/customers-data.service';
import { RepositoryStateService } from '../../services/repository-state/repository-state.service';
import { Router } from '@angular/router';
import { DatePipe, CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { ToastrService } from 'ngx-toastr';
import { DeleteConfirmDialogComponent } from '../delete-confirm-dialog/delete-confirm-dialog.component';

@Component({
    selector: 'app-customer-table-material',
    standalone: true,
    imports: [MatSortModule, MatDialogModule, DatePipe, CommonModule, MatButtonModule, MatFormFieldModule, MatInputModule, MatTableModule, MatSortModule, MatPaginatorModule],
    templateUrl: './customer-table-material.component.html',
    styleUrl: './customer-table-material.component.css'
})

export class CustomerTableMaterialComponent {
    displayedColumns: string[] = ['id', 'firstName', 'lastName', 'email', 'dateOfBirth', 'city', 'Action'];
    dataSource = new MatTableDataSource<MCustomer>([]);

    public stateService = inject(RepositoryStateService);
    private customersService = inject(CustomersDataService);
    private router = inject(Router);

    private dialog = inject(MatDialog);
    private toastr = inject(ToastrService);

    @ViewChild(MatPaginator) paginator!: MatPaginator;
    @ViewChild(MatSort) sort!: MatSort;

    ngOnInit(): void {
        this.loadCustomers();
    }

    loadCustomers(): void {
        this.customersService.getCustomers(this.stateService.choice()).subscribe({
            next: (data: MCustomer[]) => {
                this.dataSource.data = data;
                this.dataSource.paginator = this.paginator;
                this.dataSource.sort = this.sort;
            },
            error: (error) => {
                console.error('Failed to load customer list items:', error);
            }
        });
    }

    ngAfterViewInit() {
        this.dataSource.paginator = this.paginator;
        this.dataSource.sort = this.sort;
    }

    applyFilter(event: Event) {
        const filterValue = (event.target as HTMLInputElement).value;
        this.dataSource.filter = filterValue.trim().toLowerCase();

        if (this.dataSource.paginator) {
            this.dataSource.paginator.firstPage();
        }
    }

    onEditCustomer(customer: MCustomer): void {
        if (customer.id) {
            const currentRepo = this.stateService.choice();

            this.router.navigate(['/update-customer', customer.id], {
                queryParams: { repo: currentRepo }
            });
        }
    }

    onDeleteCustomer(customer: MCustomer): void {
        const customerId = customer.id;
        const customerName = `${customer.firstName} ${customer.lastName}`;

        if (!customerId) return;

        const dialogRef = this.dialog.open(DeleteConfirmDialogComponent, {
            width: '400px',
            disableClose: true,
            data: { name: customerName }
        });

        dialogRef.afterClosed().subscribe((confirmed: boolean) => {
            if (confirmed) {
                this.customersService.DeleteCustomer(this.stateService.choice(), customerId).subscribe({
                    next: () => {
                        this.toastr.success(`Customer record for ${customerName} was deleted successfully.`, 'Deleted');
                        this.loadCustomers();
                    },
                    error: (err) => {
                        this.toastr.error('Database rejected the removal request pipeline.', 'Deletion Failed');
                        console.error('Deletion request rejected:', err);
                    }
                });
            }
        });
    }

    onRowClick(customer: MCustomer): void {
        if (customer.id) {
            const activeRepo = this.stateService.choice();
            this.router.navigate(['/details-customer', customer.id], {
                queryParams: { repo: activeRepo }
            });
        }
    }

    onRefresh() {
        this.loadCustomers();
    }
}
