import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomerTableMaterialComponent } from './customer-table-material.component';

describe('CustomerTableMaterialComponent', () => {
  let component: CustomerTableMaterialComponent;
  let fixture: ComponentFixture<CustomerTableMaterialComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [CustomerTableMaterialComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomerTableMaterialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
