export class MCustomer {
    id?: number;
    firstName?: string;
    lastName?: string;
    email?: string;
    dateOfBirth?: Date;
    city?: string;
    createdAt?: Date;
    updatedAt?: Date;
}