export interface Employee {
    id: number;
    first_name: string;
    last_name: string;
    designation: string;
    salary: number;
    department_id: number;
    department_name: string;
    is_delete: number;
}