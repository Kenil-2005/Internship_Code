import { Component, inject, OnInit } from '@angular/core';
import { EmployeeServiceService } from '../../service/employee-service.service';
import { employee } from '../../Employee';
import { Router } from '@angular/router';

@Component({
    selector: 'app-employee-list',
    standalone: true,
    imports: [],
    templateUrl: './employee-list.component.html',
    styleUrl: './employee-list.component.css'
})
export class EmployeeListComponent implements OnInit {
    private router = inject(Router);

    EmployeeDataService = inject(EmployeeServiceService);

    EmployeeData: employee[] = [];

    ngOnInit(): void {
        this.EmployeeData = this.EmployeeDataService.getEmployeeData();
    }

    onCardClick(id: any) {
        console.log("Navigating with ID:", id);
        this.router.navigate(['/employee-details', id]);
    }
}
