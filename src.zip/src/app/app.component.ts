import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeDataComponent } from "./components/employee-data/employee-data.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, EmployeeDataComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'employee-welcome-portal';
}
