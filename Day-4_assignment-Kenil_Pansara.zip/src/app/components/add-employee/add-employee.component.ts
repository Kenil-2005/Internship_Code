import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { EmployeeServiceService } from '../../service/employee-service.service';
import { employee } from '../../Employee';

@Component({
    selector: 'app-add-employee',
    standalone: true,
    imports: [CommonModule, ReactiveFormsModule],
    templateUrl: './add-employee.component.html',
    styleUrl: './add-employee.component.css'
})
export class AddEmployeeComponent implements OnInit {
    private fb = inject(FormBuilder);
    private employeeService = inject(EmployeeServiceService);
    private router = inject(Router);

    employeeForm!: FormGroup;

    // Toast control flags
    showToast: boolean = false;
    toastMessage: string = '';

    ngOnInit(): void {
        this.initForm();
    }

    private initForm(): void {
        this.employeeForm = this.fb.group({
            id: [null, [Validators.required, Validators.min(1)]],
            name: ['', [Validators.required, Validators.minLength(3)]],
            department: ['', [Validators.required]],
            designation: ['', [Validators.required]],
            salary: [null, [Validators.required, Validators.min(0)]],
            doj: [new Date().toISOString().substring(0, 10), [Validators.required]],
            image: ['./assets/profile-pic.jpg', [Validators.required]],
            activeStatus: [true]
        });
    }

    get f() {
        return this.employeeForm.controls;
    }

    onSave(): void {
        if (this.employeeForm.invalid) {
            this.employeeForm.markAllAsTouched();
            return;
        }

        const formValue = this.employeeForm.value;
        const newEmployee: employee = {
            ...formValue,
            id: Number(formValue.id),
            salary: Number(formValue.salary),
            doj: new Date(formValue.doj)
        };

        this.employeeService.getEmployeeData().push(newEmployee);

        this.toastMessage = `Success! Employee "${newEmployee.name}" has been registered.`;
        this.showToast = true;

        this.employeeForm.reset({
            id: null,
            name: '',
            department: '',
            designation: '',
            salary: null,
            doj: new Date().toISOString().substring(0, 10),
            image: './assets/profile-pic.jpg',
            activeStatus: true
        });

        setTimeout(() => {
            this.showToast = false;
        }, 4000);
    }

    onCancel(): void {
        this.router.navigate(['/employee']);
    }
}