import { Component, inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, Validators, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MCustomer } from '../../Model/MCustomer';
import { CustomersDataService } from '../../services/customers-data/customers-data.service';
import { RepositoryStateService } from '../../services/repository-state/repository-state.service';
import { ToastrService } from 'ngx-toastr';
import { SafeResourceUrl } from '@angular/platform-browser';

@Component({
	selector: 'app-add-customers',
	standalone: true,
	imports: [FormsModule, CommonModule, ReactiveFormsModule],
	templateUrl: './add-customers.component.html',
	styleUrl: './add-customers.component.css'
})
export class AddCustomersComponent implements OnInit {
	private fb = inject(FormBuilder);
	private customersService = inject(CustomersDataService)
	private router = inject(Router);
	private stateService = inject(RepositoryStateService);
	private toastr = inject(ToastrService);

	customerForm!: FormGroup;
	isSubmitting = false;
	errorMessage = '';

	ngOnInit(): void {
		this.customerForm = this.fb.group({
			first_name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
			last_name: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
			email: ['', [Validators.required, Validators.email, Validators.pattern(/^[a-zA-Z0-9._%+-]+@[a-zA-Z]+\.[a-zA-Z]{2,}$/)]],
			DOB: ['', [Validators.required, this.pastDateValidator]],
			city: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]],
		})
	}

	get f() {
		return this.customerForm.controls;
	}

	get currentRepoChoice(): string {
		return this.stateService.choice();
	}

	private pastDateValidator(control: any): { [key: string]: boolean } | null {
		if (control.value) {
			const selectedDate = new Date(control.value);
			const today = new Date();
			if (selectedDate > today) {
				return { 'futureDate': true };
			}
		}
		return null;
	}

	onSubmit(): void {
		if (this.customerForm.invalid) {
			this.customerForm.markAllAsTouched();
			return;
		}

		this.isSubmitting = true;
		this.errorMessage = '';

		const IChoice = this.stateService.choice();

		const body: MCustomer = {
			firstName: this.customerForm.value.first_name,
			lastName: this.customerForm.value.last_name,
			email: this.customerForm.value.email,
			dateOfBirth: this.customerForm.value.DOB ? new Date(this.customerForm.value.DOB) : undefined,
			city: this.customerForm.value.city
		};


		this.customersService.CreateCustomer(IChoice, body).subscribe({
			next: (response) => {
				this.isSubmitting = false;

				this.toastr.success('New customer account registered successfully.', 'Success');

				this.router.navigate(['/home']);
			},
			error: (error) => {
				this.isSubmitting = false;

				if (error?.error?.message.includes('UNIQUE KEY') || error?.error?.message.includes('duplicate key')) {
					this.errorMessage = 'A customer with this email address already exists.';
				} else {
					this.errorMessage = 'An unexpected server error occurred. Please try again.';
				}

				this.toastr.error(this.errorMessage, 'Submission Failed');

				console.error('Submission failed:', error.error.message);
			}
		});
	}

	onReset(): void {
		this.router.navigate(['/home']);
	}

}
