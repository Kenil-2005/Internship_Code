    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Text.Json.Serialization;
    using customer_app_back_end.Interface;
using customer_app_back_end.Validation;

    namespace customer_app_back_end
    {
        [Table("Customer_Kenil")]
        public class Customer : ICustomer
        {
            [Key]
            [Column("id")]
            public int Id { get; set; }

            [Required(ErrorMessage = "First name is mandatory.")]
            [StringLength(100, MinimumLength = 2)]
            [Column("first_name")]
            public string FirstName { get; set; } = string.Empty;

            [Required(ErrorMessage = "Last name is mandatory.")]
            [StringLength(100, MinimumLength = 2)]
            [Column("last_name")]
            public string LastName { get; set; } = string.Empty;

            [Required(ErrorMessage = "Email address is mandatory.")]
            [EmailAddress]
            [Column("email")]
            public string Email { get; set; } = string.Empty;

            [Required(ErrorMessage = "Date of birth is mandatory.")]
            // [DateOfBirth] 
            [Column("date_of_birth")]
            public DateTime DateOfBirth { get; set; }

            [Required(ErrorMessage = "City location is mandatory.")]
            [Column("city")]
            public string City { get; set; } = string.Empty;

            [Column("created_at")]
            public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

            [Column("updated_at")]
            public DateTime UpdatedAt { get; set; } = DateTime.UtcNow;

            [Column("isDeleted")]
            [JsonIgnore]
            public bool IsDeleted { get; set; } = false;
        }
    }
