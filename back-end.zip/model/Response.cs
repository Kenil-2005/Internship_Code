namespace customer_app_back_end.model
{
    public class Response<T>
    {
        public T? Data { get; set; }
        public string Message { get; set; } = "";
        public bool status { get; set; } = false;
    }
}
