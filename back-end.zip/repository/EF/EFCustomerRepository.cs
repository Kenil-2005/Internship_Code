using customer_app_back_end.Interface;
using customer_app_back_end.model;
using Microsoft.EntityFrameworkCore;

namespace customer_app_back_end.repository.EF
{
    public class EFCustomerRepository : ICustomerRepository
    {
        private readonly AppDbContext _context;

        public EFCustomerRepository(AppDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
        }

        // GET
        public async Task<Response<IEnumerable<Customer>>> GetAllCustomer(int? id)
        {
            var response = new Response<IEnumerable<Customer>>();
            try
            {
                var query = _context.Customers.Where(c => !c.IsDeleted);

                if (id.HasValue && id.Value > 0)
                {
                    query = query.Where(c => c.Id == id.Value);
                }

                response.Data = await query.ToListAsync();
                response.status = true;
                response.Message = "Customers fetched successfully via EF Core.";
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Message = $"EF Core Exception raised: {ex.Message}";
            }
            return response;
        }

        // POST
        public async Task<Response<bool>> CreateCustomer(Customer customer)
        {
            var response = new Response<bool>();
            try
            {
                customer.CreatedAt = DateTime.UtcNow;
                customer.UpdatedAt = DateTime.UtcNow;
                customer.IsDeleted = false;

                await _context.Customers.AddAsync(customer);
                int rowsAffected = await _context.SaveChangesAsync();

                if (rowsAffected > 0)
                {
                    response.status = true;
                    response.Data = true;
                    response.Message = "Customer registered successfully via EF Core.";
                }
                else
                {
                    response.status = false;
                    response.Data = false;
                    response.Message = "No changes were written to the storage layer.";
                }
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = false;
                response.Message = $"EF Core Exception raised: {ex.Message}";
            }
            return response;
        }

        // PUT
        public async Task<Response<bool>> UpdateCustomer(int id, Customer customer)
        {
            var response = new Response<bool>();
            try
            {
                var existingCustomer = await _context.Customers.FirstOrDefaultAsync(c =>
                    c.Id == id && !c.IsDeleted
                );

                if (existingCustomer == null)
                {
                    response.status = false;
                    response.Data = false;
                    response.Message = $"Customer with ID {id} was not found or is deleted.";
                    return response;
                }

                existingCustomer.FirstName = customer.FirstName;
                existingCustomer.LastName = customer.LastName;
                existingCustomer.Email = customer.Email;
                existingCustomer.City = customer.City;
                existingCustomer.DateOfBirth = customer.DateOfBirth;
                existingCustomer.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                response.status = true;
                response.Data = true;
                response.Message = "Customer updated successfully via EF Core.";
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = false;
                response.Message = $"EF Core Exception raised: {ex.Message}";
            }
            return response;
        }

        // DELETE
        public async Task<Response<bool>> DeleteCustomer(int id)
        {
            var response = new Response<bool>();
            try
            {
                var existingCustomer = await _context.Customers.FirstOrDefaultAsync(c =>
                    c.Id == id && !c.IsDeleted
                );

                if (existingCustomer == null)
                {
                    response.status = false;
                    response.Data = false;
                    response.Message =
                        $"Customer with ID {id} was not found or is already deleted.";
                    return response;
                }

                existingCustomer.IsDeleted = true;
                existingCustomer.UpdatedAt = DateTime.UtcNow;

                await _context.SaveChangesAsync();

                response.status = true;
                response.Data = true;
                response.Message = "Customer deleted successfully via EF Core.";
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = false;
                response.Message = $"EF Core Exception raised: {ex.Message}";
            }
            return response;
        }
    }
}
