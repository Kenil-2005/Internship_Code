import { Injectable } from '@angular/core';
import { employee } from '../Employee';

@Injectable({
    providedIn: 'root'
})
export class EmployeeServiceService {
    EmployeeData: employee[] = [
        { id: 101, name: 'kenil pansara', department: ' IT', designation: 'Developer', salary: 50000, doj: new Date('2026-06-18'), image: './assets/profile-pic.jpg', activeStatus: true },
        { id: 102, name: 'divya patel', department: 'HR', designation: 'QA', salary: 80000, doj: new Date('2026-06-18'), image: './assets/profile-pic.jpg', activeStatus: false },
        { id: 103, name: 'mihir modh', department: 'Finance', designation: 'project manager', salary: 40000, doj: new Date('2026-06-18'), image: './assets/profile-pic.jpg', activeStatus: true },
        { id: 104, name: 'shruti thakkar', department: 'Marketing', designation: 'BDE', salary: 500000, doj: new Date('2026-06-18'), image: './assets/profile-pic.jpg', activeStatus: false },
        { id: 105, name: 'krish dave', department: 'IT', designation: 'BDA', salary: 50000, doj: new Date('2026-06-18'), image: './assets/profile-pic.jpg', activeStatus: true },
    ];

    getEmployeeData(): employee[] {
        return this.EmployeeData;
    }
}
