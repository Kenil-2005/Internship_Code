import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { EmployeeDashboardComponent } from "./components/employee-dashboard/employee-dashboard.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, EmployeeDashboardComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'employee-managment-portal-04';
}
