using System;
using customer_app_back_end.Interface;
using customer_app_back_end.model;
using customer_app_back_end.repository.ADO;
using customer_app_back_end.repository.EF;
using Microsoft.AspNetCore.Mvc;

namespace customer_app_back_end.Controllers;

[ApiController]
[Route("api/customer")]
public class CustomerManagementController : ControllerBase
{
    private readonly ADOCustomerRepository _adoCustomerRepository;
    private readonly EFCustomerRepository _efCustomerRepository;

    public CustomerManagementController(
        ADOCustomerRepository adoCustomerRepository,
        EFCustomerRepository efCustomerRepository
    )
    {
        _adoCustomerRepository = adoCustomerRepository;
        _efCustomerRepository = efCustomerRepository;
    }

    private ICustomerRepository GetRepositry(string choice)
    {
        return string.Equals(choice, "true", StringComparison.OrdinalIgnoreCase)
            ? _adoCustomerRepository
            : _efCustomerRepository;
    }

    [HttpGet]
    public async Task<ActionResult<Response<List<Customer>>>> GetAllCustomer(
        [FromHeader(Name = "choice")] string choice,
        int? id
    )
    {
        var repository = GetRepositry(choice);
        // Console.WriteLine(repository);
        var response = await repository.GetAllCustomer(id);

        if (!response.status)
        {
            return StatusCode(500, response);
        }

        return Ok(response);
    }

    [HttpPost]
    public async Task<IActionResult> PostCustomer(
        [FromHeader(Name = "choice")] string choice,
        [FromBody] Customer customer
    )
    {
        if (customer == null)
        {
            return BadRequest("Customer data cannot be empty.");
        }
        var repository = GetRepositry(choice);
        // Console.WriteLine(repository);
        var response = await repository.CreateCustomer(customer);

        if (!response.status)
        {
            return StatusCode(500, response);
        }

        return Ok(response);
    }

    [HttpPut("{id}")]
    public async Task<IActionResult> UpdateCustomer(
        int id,
        [FromHeader(Name = "choice")] string choice,
        [FromBody] Customer customer
    )
    {
        if (customer == null)
        {
            return BadRequest("Updated customer payload cannot be null.");
        }

        var repository = GetRepositry(choice);
        // Console.WriteLine(repository);
        var response = await repository.UpdateCustomer(id, customer);

        if (!response.status)
        {
            if (response.Message.Contains("not found"))
            {
                return NotFound(response);
            }
            return StatusCode(500, response);
        }

        return Ok(response);
    }

    [HttpDelete("{id}")]
    public async Task<IActionResult> DeleteCustomer(
        int id,
        [FromHeader(Name = "choice")] string choice
    )
    {
        var repository = GetRepositry(choice);
        // Console.WriteLine(repository);
        var response = await repository.DeleteCustomer(id);

        if (!response.status)
        {
            if (response.Message.Contains("not found"))
            {
                return NotFound(response);
            }
            return StatusCode(500, response);
        }

        return Ok(response);
    }
}
