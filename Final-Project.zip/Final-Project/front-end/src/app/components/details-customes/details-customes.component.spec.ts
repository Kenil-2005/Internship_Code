import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailsCustomesComponent } from './details-customes.component';

describe('DetailsCustomesComponent', () => {
  let component: DetailsCustomesComponent;
  let fixture: ComponentFixture<DetailsCustomesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [DetailsCustomesComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(DetailsCustomesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
