import { Component } from '@angular/core';
import { CustomerTableMaterialComponent } from "../customer-table-material/customer-table-material.component";

@Component({
  selector: 'app-customer-main',
  standalone: true,
  imports: [CustomerTableMaterialComponent],
  templateUrl: './customer-main.component.html',
  styleUrl: './customer-main.component.css'
})
export class CustomerMainComponent {

}
