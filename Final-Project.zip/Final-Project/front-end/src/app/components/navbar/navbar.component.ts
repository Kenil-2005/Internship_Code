import { Component, inject } from '@angular/core';
import { RouterLink, RouterLinkActive } from "@angular/router";
import { RepositoryStateService } from '../../services/repository-state/repository-state.service';

@Component({
    selector: 'app-navbar',
    standalone: true,
    imports: [RouterLink, RouterLinkActive],
    templateUrl: './navbar.component.html',
    styleUrl: './navbar.component.css'
})
export class NavbarComponent {
    public stateService = inject(RepositoryStateService);

    onToggleChange(event: Event): void {
        const isChecked = (event.target as HTMLInputElement).checked;

        const choiceValue = isChecked ? 'true' : 'false';
        this.stateService.setChoice(choiceValue);
    }
}
