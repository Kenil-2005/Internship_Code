import { Component, inject } from '@angular/core';
import { FormBuilder, FormGroup, FormsModule, ReactiveFormsModule, Validators } from '@angular/forms';
import { CustomersDataService } from '../../services/customers-data/customers-data.service';
import { ActivatedRoute, Router } from '@angular/router';
import { RepositoryStateService } from '../../services/repository-state/repository-state.service';
import { MCustomer } from '../../Model/MCustomer';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';

@Component({
    selector: 'app-update-customer',
    standalone: true,
    imports: [FormsModule, CommonModule, ReactiveFormsModule],
    templateUrl: './update-customer.component.html',
    styleUrl: './update-customer.component.css'
})
export class UpdateCustomerComponent {
    private fb = inject(FormBuilder);
    private customersService = inject(CustomersDataService);
    private router = inject(Router);
    private route = inject(ActivatedRoute);
    public stateService = inject(RepositoryStateService);
    private toastr = inject(ToastrService);

    customerForm!: FormGroup;
    isSubmitting = false;
    isLoading = true;
    customerId!: number;
    repoChoice = 'true';

    ngOnInit(): void {
        this.customerForm = this.fb.group({
            firstName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
            lastName: ['', [Validators.required, Validators.minLength(2), Validators.maxLength(50)]],
            email: ['', [Validators.required, Validators.email]],
            dateOfBirth: ['', [Validators.required, this.pastDateValidator]],
            city: ['', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]]
        });

        this.customerId = Number(this.route.snapshot.paramMap.get('id'));
        this.repoChoice = this.route.snapshot.queryParamMap.get('repo') || 'true';

        if (this.customerId) {
            this.loadCustomerDetails();
        } else {
            this.toastr.error('Invalid Customer path reference.', 'Error');
            this.isLoading = false;
        }
    }

    get f() {
        return this.customerForm.controls;
    }

    get currentRepoChoice(): string {
        return this.stateService.choice();
    }

    private loadCustomerDetails(): void {
        this.customersService.getCustomers(this.repoChoice).subscribe({
            next: (list: MCustomer[]) => {
                const customer = list.find(c => (c.id ?? c.id) === this.customerId);

                if (customer) {
                    let formattedDate = '';
                    if (customer.dateOfBirth) {
                        formattedDate = new Date(customer.dateOfBirth).toISOString().substring(0, 10);
                    }

                    this.customerForm.patchValue({
                        firstName: customer.firstName,
                        lastName: customer.lastName,
                        email: customer.email,
                        dateOfBirth: formattedDate,
                        city: customer.city
                    });
                } else {
                    this.toastr.error('Customer record could not be found.', 'Not Found');
                }
                this.isLoading = false;
            },
            error: (err) => {
                this.toastr.error('Failed to fetch profile details.', 'Network Error');
                this.isLoading = false;
            }
        });
    }

    private pastDateValidator(control: any): { [key: string]: boolean } | null {
        if (control.value) {
            const selectedDate = new Date(control.value);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            if (selectedDate > today) {
                return { 'futureDate': true };
            }
        }
        return null;
    }

    onSubmit(): void {
        if (this.customerForm.invalid) {
            this.customerForm.markAllAsTouched();
            return;
        }

        this.isSubmitting = true;
        var errorMessage = '';

        const body: MCustomer = {
            firstName: this.customerForm.value.firstName,
            lastName: this.customerForm.value.lastName,
            email: this.customerForm.value.email,
            dateOfBirth: this.customerForm.value.dateOfBirth ? new Date(this.customerForm.value.dateOfBirth) : undefined,
            city: this.customerForm.value.city
        };

        this.customersService.UpdateCustomer(this.repoChoice, this.customerId, body).subscribe({
            next: () => {
                this.isSubmitting = false;

                this.toastr.success('Customer profile details updated successfully.', 'Success');

                this.router.navigate(['/home']);
            },

            error: (error) => {
                this.isSubmitting = false;

                if (error?.error?.message.includes('UNIQUE KEY') || error?.error?.message.includes('duplicate key')) {
                    errorMessage = 'A customer with this email address already exists.';
                } else {
                    errorMessage = 'An unexpected server error occurred. Please try again.';
                }

                this.toastr.error(errorMessage, 'Update Failed');

                console.error('Update request rejected:', error);
            }
        });
    }

    onCancel(): void {
        this.router.navigate(['/home']);
    }
}
