import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Employee } from '../../Employee';

@Injectable({
    providedIn: 'root'
})
export class EmployeeServiceService {
    private http = inject(HttpClient);
    private apiUrl = 'http://localhost:5000/api/users';

    getEmployee(): Observable<Employee[]> {
        return this.http.get<any>(this.apiUrl).pipe(
            // Unpack the 'data' property from your Swagger response object
            map(response => response.data || [])
        );
    }
}