using Microsoft.EntityFrameworkCore;

namespace customer_app_back_end.model
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options) { }

        public DbSet<Customer> Customers { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Customer>().HasIndex(e => e.Email).IsUnique();
            base.OnModelCreating(modelBuilder);
        }
    }
}
