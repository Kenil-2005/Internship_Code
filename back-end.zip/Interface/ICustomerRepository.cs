using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using customer_app_back_end.model;

namespace customer_app_back_end.Interface
{
    public interface ICustomerRepository
    {
        Task<Response<IEnumerable<Customer>>> GetAllCustomer(int? id);
        Task<Response<bool>> CreateCustomer(Customer customer);
        Task<Response<bool>> UpdateCustomer(int id, Customer customer);
        Task<Response<bool>> DeleteCustomer(int id);
    }
}
