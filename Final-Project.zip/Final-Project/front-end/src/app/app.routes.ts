import { Routes } from '@angular/router';
import { CustomerMainComponent } from './components/customer-main/customer-main.component';
import { DetailsCustomesComponent } from './components/details-customes/details-customes.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { AddCustomersComponent } from './components/add-customers/add-customers.component';
import { UpdateCustomerComponent } from './components/update-customer/update-customer.component';

export const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: CustomerMainComponent },
    { path: 'details-customer/:id', component: DetailsCustomesComponent },
    { path: 'update-customer/:id', component: UpdateCustomerComponent },
    { path: 'add-customer', component: AddCustomersComponent },
    { path: '**', component: NotFoundComponent }
];
