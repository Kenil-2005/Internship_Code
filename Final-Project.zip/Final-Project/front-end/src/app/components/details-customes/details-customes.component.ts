import { Component, inject } from '@angular/core';
import { MCustomer } from '../../Model/MCustomer';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { CustomersDataService } from '../../services/customers-data/customers-data.service';
import { CommonModule } from '@angular/common';
import { ToastrService } from 'ngx-toastr';
import { RepositoryStateService } from '../../services/repository-state/repository-state.service';
@Component({
    selector: 'app-details-customes',
    standalone: true,
    imports: [RouterLink, CommonModule],
    templateUrl: './details-customes.component.html',
    styleUrl: './details-customes.component.css'
})
export class DetailsCustomesComponent {
    private route = inject(ActivatedRoute);
    private router = inject(Router);
    private customersService = inject(CustomersDataService);
    private toastr = inject(ToastrService);
    private stateService = inject(RepositoryStateService);

    customer: MCustomer | null = null;
    isLoading = true;
    repoChoice = 'true';

    ngOnInit(): void {
        const idParam = this.route.snapshot.paramMap.get('id');
        this.repoChoice = this.route.snapshot.queryParamMap.get('repo') || 'true';

        if (idParam) {
            this.loadCustomerProfile(Number(idParam));
        } else {
            this.toastr.error('Invalid link reference parameters.', 'Navigation Error');
            this.isLoading = false;
            this.router.navigate(['/home']);
        }
    }

    get currentRepoChoice(): string {
        return this.stateService.choice();
    }

    private loadCustomerProfile(id: number): void {
        this.customersService.getCustomers(this.repoChoice).subscribe({
            next: (list: MCustomer[]) => {
                const found = list.find(c => c.id === id);
                if (found) {
                    this.customer = found;
                } else {
                    this.toastr.warning('The requested customer profile could not be located.', 'Not Found');
                    this.router.navigate(['/home']);
                }
                this.isLoading = false;
            },
            error: (err) => {
                this.toastr.error('Failed to fetch data attributes from the API pipeline.', 'Network Error');
                this.isLoading = false;
                this.router.navigate(['/customers']);
            }
        });
    }

    onBack(): void {
        this.router.navigate(['/home']);
    }
}
