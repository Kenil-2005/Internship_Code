export interface Employee {
    id: number,
    name: string,
    department: string,
    designation: string,
    salary: number,
    image: string,
    promote: boolean,
    rate?: number
}