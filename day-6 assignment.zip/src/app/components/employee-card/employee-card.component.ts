import { Component, EventEmitter, inject, Input, output, Output } from '@angular/core';
import { Employee } from '../../Employee';
import { CommonModule, UpperCasePipe } from '@angular/common';
import { MatDialog } from '@angular/material/dialog';
import { EmployeeDialogComponent } from '../employee-dialog/employee-dialog.component';

@Component({
    selector: 'app-employee-card',
    standalone: true,
    imports: [CommonModule],
    templateUrl: './employee-card.component.html',
    styleUrl: './employee-card.component.css'
})
export class EmployeeCardComponent {
    @Input() employee!: Employee;
    @Output() promoteEmployee: EventEmitter<Employee> = new EventEmitter();
    @Output() promoteMessage: EventEmitter<string> = new EventEmitter();
    @Output() rateEmployee: EventEmitter<string> = new EventEmitter();

    PromotedEmployee(employee: Employee) {
        console.log(employee);
        this.promoteEmployee.emit(employee);
    }

    PromotedMessage(employee: Employee) {
        if (employee.promote) {
            this.promoteMessage.emit(`Employee ${employee.name} is Promoted Successfully.`);
        } else {
            this.promoteMessage.emit(`Employee ${employee.name} is Demoted Successfully.`);
        }
    }

    RateEmployee(employee: Employee) {
        this.rateEmployee.emit(`Employee ${employee.name} recive 5 star rating.`)
    }

    dialog = inject(MatDialog);

    openDialog(employee: Employee) {
        this.dialog.open(EmployeeDialogComponent, {
            data: {
                Name: employee.name,
                Department: employee.department,
                Salary: employee.salary
            },
        });
    }
}