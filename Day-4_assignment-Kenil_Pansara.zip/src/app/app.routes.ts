import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
import { AddEmployeeComponent } from './components/add-employee/add-employee.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { AboutComponent } from './components/about/about.component';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';

export const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: "full" },
    { path: 'home', component: HomeComponent },
    { path: 'about', component: AboutComponent },
    // { path: 'employee-details', component: EmployeeDetailsComponent },
    { path: 'employee-details/:id', component: EmployeeDetailsComponent },
    { path: 'employee', component: EmployeeListComponent },
    { path: 'add-employee', component: AddEmployeeComponent },
    { path: "**", component: NotFoundComponent }
];
