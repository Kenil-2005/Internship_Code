using System;
using System.Collections.Generic;
using System.Data;
using customer_app_back_end.Interface;
using customer_app_back_end.model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;

namespace customer_app_back_end.repository.ADO
{
    public class ADOCustomerRepository : ICustomerRepository
    {
        private readonly string connStr;

        public ADOCustomerRepository(IConfiguration configuration)
        {
            connStr =
                configuration.GetConnectionString("DefaultConnection")
                ?? throw new ArgumentNullException(
                    "Connection string layout is missing in configuration mapping."
                );
        }

        // GET
        public async Task<Response<IEnumerable<Customer>>> GetAllCustomer(int? id)
        {
            var response = new Response<IEnumerable<Customer>>();
            List<Customer> customerList = new List<Customer>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    // string query =
                    //     "select id,first_name,last_name,email,date_of_birth,city,created_at,updated_at,isDeleted "
                    //     + "from [Training2026].[dbo].[Customer_Kenil] "
                    //     + "where isDeleted = 0 and "
                    //     + "(@Id IS NULL OR @Id = 0 OR ID = @Id) ";

                    using (SqlCommand cmd = new SqlCommand("dbo.spGetCustomerDetails_Kenil", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.Add("@Id", SqlDbType.Int).Value =
                            (id == null || id == 0) ? DBNull.Value : id;

                        await conn.OpenAsync();

                        using (SqlDataReader reader = await cmd.ExecuteReaderAsync())
                        {
                            int idOrd = reader.GetOrdinal("id");
                            int firstNameOrd = reader.GetOrdinal("first_name");
                            int lastNameOrd = reader.GetOrdinal("last_name");
                            int emailOrd = reader.GetOrdinal("email");
                            int dobOrd = reader.GetOrdinal("date_of_birth");
                            int cityOrd = reader.GetOrdinal("city");
                            int createdAtOrd = reader.GetOrdinal("created_at");
                            int updatedAtOrd = reader.GetOrdinal("updated_at");

                            while (await reader.ReadAsync())
                            {
                                customerList.Add(
                                    new Customer
                                    {
                                        Id = reader.GetInt32(idOrd),
                                        FirstName = reader.IsDBNull(firstNameOrd)
                                            ? string.Empty
                                            : reader.GetString(firstNameOrd),
                                        LastName = reader.IsDBNull(lastNameOrd)
                                            ? string.Empty
                                            : reader.GetString(lastNameOrd),
                                        Email = reader.IsDBNull(emailOrd)
                                            ? string.Empty
                                            : reader.GetString(emailOrd),
                                        City = reader.IsDBNull(cityOrd)
                                            ? string.Empty
                                            : reader.GetString(cityOrd),
                                        DateOfBirth = reader.GetDateTime(dobOrd),
                                        CreatedAt = reader.GetDateTime(createdAtOrd),
                                        UpdatedAt = reader.GetDateTime(updatedAtOrd),
                                    }
                                );
                            }
                        }
                    }
                }
                response.status = true;
                response.Data = customerList;
                response.Message = "Customers fetched successfully via ADO.";
                return response;
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = new List<Customer>();
                response.Message = $"Database Exception raised: {ex.Message}";
            }
            return response;
        }

        // POST
        public async Task<Response<bool>> CreateCustomer(Customer customer)
        {
            var response = new Response<bool>();
            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                {
                    // string query =
                    //     "INSERT INTO [dbo].[Customer_Kenil] ([first_name],[last_name],[email],[date_of_birth],[city],[created_at],[updated_at]) "
                    //     + "VALUES (@FirstName, @LastName, @Email, @DateOfBirth, @City, @CreatedAt,@UpdatedAt) ";

                    using (SqlCommand cmd = new SqlCommand("dbo.spInsertCustomer_Kenil", conn))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;

                        cmd.Parameters.AddWithValue("@FirstName", customer.FirstName);
                        cmd.Parameters.AddWithValue("@LastName", customer.LastName);
                        cmd.Parameters.AddWithValue("@Email", customer.Email);
                        cmd.Parameters.AddWithValue("@City", customer.City);
                        cmd.Parameters.AddWithValue("@DateOfBirth", customer.DateOfBirth);
                        cmd.Parameters.AddWithValue("@CreatedAt", DateTime.UtcNow);
                        cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);

                        await conn.OpenAsync();
                        int rowsAffected = await cmd.ExecuteNonQueryAsync();

                        if (rowsAffected > 0)
                        {
                            response.status = true;
                            response.Data = true;
                            response.Message = "Customer registered successfully via ADO.";
                        }
                        else
                        {
                            response.status = false;
                            response.Data = false;
                            response.Message = "No rows were inserted into the database.";
                        }
                    }
                    return response;
                }
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = false;
                response.Message = $"Database Exception raised: {ex.Message}";
            }
            return response;
        }

        // PUT
        public async Task<Response<bool>> UpdateCustomer(int id, Customer customer)
        {
            var response = new Response<bool>();

            // string query =
            //     @"UPDATE [dbo].[Customer_Kenil] SET [first_name] = @FirstName, [last_name] = @LastName, [email] = @Email, [date_of_birth] = @DateOfBirth,[city] = @City, [updated_at] = @UpdatedAt WHERE [id] = @Id AND [isDeleted] = 0";

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                using (SqlCommand cmd = new SqlCommand("dbo.spUpdateCustomer_Kenil", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    cmd.Parameters.AddWithValue("@FirstName", customer.FirstName);
                    cmd.Parameters.AddWithValue("@LastName", customer.LastName);
                    cmd.Parameters.AddWithValue("@Email", customer.Email);
                    cmd.Parameters.AddWithValue("@City", customer.City);
                    cmd.Parameters.AddWithValue("@DateOfBirth", customer.DateOfBirth);
                    cmd.Parameters.AddWithValue("@UpdatedAt", DateTime.UtcNow);

                    await conn.OpenAsync();
                    int rowsAffected = await cmd.ExecuteNonQueryAsync();

                    if (rowsAffected > 0)
                    {
                        response.status = true;
                        response.Data = true;
                        response.Message = "Customer updated successfully via ADO.";
                    }
                    else
                    {
                        response.status = false;
                        response.Data = false;
                        response.Message =
                            $"Customer with ID {customer.Id} was not found or is deleted.";
                    }
                }
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = false;
                response.Message = $"Database Exception raised: {ex.Message}";
            }

            return response;
        }

        // DELETE
        public async Task<Response<bool>> DeleteCustomer(int id)
        {
            var response = new Response<bool>();

            // string query =
            //     @"UPDATE [dbo].[Customer_Kenil] SET [isDeleted] = 1, [updated_at] = @UpdatedAt WHERE [id] = @Id and [isDeleted] = 0";

            try
            {
                using (SqlConnection conn = new SqlConnection(connStr))
                using (SqlCommand cmd = new SqlCommand("dbo.spSoftDeleteCustomer_Kenil", conn))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.Add("@Id", SqlDbType.Int).Value = id;
                    cmd.Parameters.Add("@UpdatedAt", SqlDbType.DateTime).Value = DateTime.UtcNow;

                    await conn.OpenAsync();
                    int rowsAffected = await cmd.ExecuteNonQueryAsync();

                    if (rowsAffected > 0)
                    {
                        response.status = true;
                        response.Data = true;
                        response.Message = "Customer deleted successfully via ADO.";
                    }
                    else
                    {
                        response.status = false;
                        response.Data = false;
                        response.Message =
                            $"Customer with ID {id} was not found or is already deleted.";
                    }
                }
            }
            catch (Exception ex)
            {
                response.status = false;
                response.Data = false;
                response.Message = $"Database Exception raised: {ex.Message}";
            }

            return response;
        }
    }
}
