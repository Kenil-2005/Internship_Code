import { Component } from '@angular/core';

@Component({
  selector: 'app-footer-component',
  standalone: true,
  imports: [],
  templateUrl: './footer-component.component.html',
  styleUrl: './footer-component.component.css'
})
export class FooterComponentComponent {
  FooterData = { Name: 'Sharad Savariya', Batch: 'Stridely-B26', Year: 2026 };
}
