import { Routes } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { EmployeeListComponent } from './components/employee-list/employee-list.component';
// import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';
import { EmployeeUpdateComponent } from './components/employee-update/employee-update.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { EmployeeDetailsComponent } from './components/employee-details/employee-details.component';
// import { AddEmployeeComponent } from './components/add-employee/add-employee.component';

export const routes: Routes = [
    { path: '', redirectTo: '/home', pathMatch: 'full' },
    { path: 'home', component: HomeComponent },
    { path: 'employees', component: EmployeeListComponent },
    // { path: 'add-employee', component: AddEmployeeComponent },
    { path: 'employee-details/:id', component: EmployeeDetailsComponent },
    { path: 'employee-update/:id', component: EmployeeUpdateComponent },
    { path: '**', component: NotFoundComponent }
];
