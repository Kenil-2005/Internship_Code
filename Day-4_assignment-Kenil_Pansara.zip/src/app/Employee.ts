export class employee {
    id?: number
    name?: string
    department?: string
    designation?: string
    salary?: number
    doj?: Date
    image?: string
    activeStatus?: boolean
}