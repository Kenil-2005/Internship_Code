import { Component, inject, Input, OnInit } from '@angular/core';
import { Router, RouterLink } from '@angular/router';
import { CommonModule } from '@angular/common';
import { EmployeeServiceService } from '../../service/employee/employee-data.service';
import { Employee } from '../../Employee';

@Component({
  selector: 'app-employee-details',
  standalone: true,
  imports: [CommonModule, RouterLink],
  templateUrl: './employee-details.component.html',
  styleUrl: './employee-details.component.css'
})
export class EmployeeDetailsComponent implements OnInit {
  private employeeService = inject(EmployeeServiceService);
  private router = inject(Router);

  // Automatically bound from the route parameter if withComponentInputBinding() is active
  @Input() id?: string | number;

  selectedEmployee: Employee | undefined;
  isLoading = true;

  ngOnInit(): void {
    if (!this.id) {
      console.error('No ID parameter supplied in the route path.');
      this.router.navigate(['/employees']);
      return;
    }

    const numericId = Number(this.id);

    this.employeeService.getEmployee().subscribe({
      next: (employees: Employee[]) => {
        // Look up the specific worker within the returned database dataset
        this.selectedEmployee = employees.find((emp: Employee) => emp.id === numericId);
        this.isLoading = false;

        if (!this.selectedEmployee) {
          console.warn(`Employee with ID ${this.id} could not be located.`);
          this.router.navigate(['/employees']);
        }
      },
      error: (err) => {
        console.error('Failed to communicate with database service profile registry:', err);
        this.isLoading = false;
        this.router.navigate(['/employees']);
      }
    });
  }
}