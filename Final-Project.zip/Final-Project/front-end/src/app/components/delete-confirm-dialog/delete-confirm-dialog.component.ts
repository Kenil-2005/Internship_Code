import { Component, inject } from '@angular/core';
import { MatDialogModule, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';

@Component({
	selector: 'app-delete-confirm-dialog',
	standalone: true,
	imports: [MatDialogModule, MatButtonModule],
	templateUrl: './delete-confirm-dialog.component.html',
	styleUrl: './delete-confirm-dialog.component.css'
})
export class DeleteConfirmDialogComponent {
	private dialogRef = inject(MatDialogRef<DeleteConfirmDialogComponent>);
	public data = inject<{ name: string }>(MAT_DIALOG_DATA);

	onCancel(): void {
		this.dialogRef.close(false);
	}

	onConfirm(): void {
		this.dialogRef.close(true);
	}
}
