import { Injectable, signal } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class RepositoryStateService {

    private currentChoice = signal<string>('true');

    readonly choice = this.currentChoice.asReadonly();

    setChoice(value: string): void {
        this.currentChoice.set(value);
    }

    get isAdo(): boolean {
        return this.currentChoice() === 'true';
    }
}
